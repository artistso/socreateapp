# Animation Studio - AI-Powered Animation App for Android

A professional-grade animation and drawing app built for the **Samsung Galaxy Tab S10+** (and all large-screen Android devices). Combines traditional animation tools with cutting-edge AI features.

## 🎯 Key Features

### 🎨 Drawing Engine
- **9+ realistic brushes**: Round, Flat, Airbrush, Pencil, Ink, Charcoal, Watercolor, Calligraphy, Eraser
- **Pressure sensitivity** via S Pen / stylus with tilt support
- **Layer system** with blend modes (Normal, Multiply, Screen, Overlay, etc.)
- **Layer transforms**: scale, rotate, offset per layer
- **Onion skinning** with configurable frame range
- **Unlimited undo/redo**
- **Color palettes** with eyedropper tool

### 🤖 AI-Powered Features

#### Auto In-Betweening (Tweening)
- Generates smooth intermediate frames between keyframes
- Optical flow estimation for raster frames
- Feature-based stroke matching and morphing
- 6 easing types: Linear, Smooth, Ease In/Out, Bounce, Elastic
- Configurable number of in-between frames (1-5+)

#### Motion Smoothing
- Temporal Gaussian smoothing across frames
- Savitzky-Golay filtering for trajectory smoothing
- Adaptive corner preservation
- Secondary motion simulation (follow-through, overshoot)

#### AI Character Rigging
- Automatic body landmark detection
- Skeletal structure generation (spine, arms, legs, head)
- Inverse Kinematics (CCD algorithm)
- Bone constraints and control handles
- Mesh deformation with bone weights

### ⏱️ Animation Timeline
- Multi-layer timeline with independent tracks
- Keyframe marking and management
- Frame-by-frame scrubbing and editing
- Playback controls (play, pause, first, last)
- Configurable FPS (1-60)
- Frame operations: add, remove, duplicate, reverse

### 📤 Export Options
- **GIF**: Animated GIF for web sharing
- **MP4**: High quality video export
- **PNG Sequence**: Frame-by-frame image export
- **WebM**: Modern web video format
- **Lottie**: Vector animation for scalable rendering
- **Project File** (.asproj): Full project backup

## 🏗️ Architecture

```
AnimationStudio/
├── app/
│   ├── build.gradle.kts          # Dependencies & build config
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/animationstudio/
│       │   ├── AnimationApp.kt           # Application class
│       │   ├── MainActivity.kt           # Entry point
│       │   ├── MainViewModel.kt          # Central state management
│       │   ├── engine/
│       │   │   ├── AnimationEngine.kt    # Core animation logic
│       │   │   ├── AnimationLayer.kt     # Layer/frame data models
│       │   │   └── RenderService.kt      # Background rendering
│       │   ├── ai/
│       │   │   ├── AIModelManager.kt     # TFLite model management
│       │   │   ├── AITweeningEngine.kt   # Auto in-betweening
│       │   │   ├── MotionSmoother.kt     # Stroke/trajectory smoothing
│       │   │   └── CharacterRigger.kt    # Skeletal rigging + IK
│       │   ├── tools/
│       │   │   └── BrushEngine.kt        # 9 brush types
│       │   ├── data/
│       │   │   ├── AppDatabase.kt        # Room database
│       │   │   ├── ProjectRepository.kt  # Data access layer
│       │   │   └── models/Models.kt      # Entities
│       │   ├── ui/
│       │   │   ├── screens/
│       │   │   │   ├── MainScreen.kt           # Navigation host
│       │   │   │   ├── ProjectHomeScreen.kt    # Project browser
│       │   │   │   ├── AnimationCanvasScreen.kt # Drawing canvas
│       │   │   │   ├── AnimationEditorScreen.kt # AI animation tools
│       │   │   │   ├── TimelineScreen.kt       # Timeline editor
│       │   │   │   └── ExportScreen.kt         # Export UI
│       │   │   └── theme/Theme.kt       # Material 3 theming
│       │   └── util/
│       │       ├── SPenHelper.kt        # S Pen integration
│       │       └── ExportUtils.kt       # Export pipeline
│       └── res/values/
│           ├── strings.xml
│           └── themes.xml
```

## 🚀 Getting Started

### Prerequisites
- Android Studio Hedgehog (2023.1+) or later
- JDK 17
- Android SDK 34
- Gradle 8.2+

### Build
```bash
cd AnimationStudio
./gradlew assembleDebug
```

### Deploy to Device
```bash
./gradlew installDebug
```

### Requirements
- Android 12+ (API 31)
- 2GB+ RAM recommended
- S Pen or active stylus for pressure sensitivity (optional)
- Large screen (tablet) recommended - optimized for Tab S10+

## 🎬 Workflow

1. **Create Project** → Set canvas size, FPS, frame count
2. **Draw Keyframes** → Use S Pen with pressure-sensitive brushes on individual frames
3. **Enable Onion Skin** → See previous/next frames as reference
4. **Add Layers** → Separate character, background, effects
5. **Auto Tween** → AI generates in-between frames between keyframes
6. **Smooth Motion** → Apply temporal smoothing to reduce jitter
7. **Auto Rig** → Create skeletal structure for character animation
8. **Export** → Share as GIF, MP4, or import into video editors

## 🧠 AI Technical Details

### Tweening Algorithm
The tweening engine uses a hybrid approach:
1. **Feature extraction** from each stroke (centroid, area, length, direction)
2. **Stroke matching** via weighted similarity scoring
3. **Catmull-Rom spline interpolation** with configurable easing
4. Optional **TFLite optical flow model** for complex raster frames

### Motion Smoothing
Three-stage pipeline:
1. **Spatial** (within frame): Adaptive Gaussian with corner detection
2. **Temporal** (across frames): Savitzky-Golay style weighted averaging
3. **Secondary motion**: Spring-damper physics for natural follow-through

### Character Rigging
1. Heuristic body landmark detection (cluster analysis + proportions)
2. Skeletal hierarchy construction (18 bones, 16 joints)
3. CCD Inverse Kinematics for pose solving
4. Gaussian-weighted mesh deformation

## 📄 License

MIT License - see LICENSE file for details.

---

*Built for creators who demand pro-grade animation tools with AI superpowers.*
